export { default as Custom404Page } from './404'
