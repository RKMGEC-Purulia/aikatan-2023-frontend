export { Custom404Page as default } from 'features/404'
