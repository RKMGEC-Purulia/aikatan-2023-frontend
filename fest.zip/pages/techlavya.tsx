import React from 'react'

const Techlavya = () => {
  return <div>Techlavya</div>
}

export default Techlavya
