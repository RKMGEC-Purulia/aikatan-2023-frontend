export { HomePage as default } from 'features/Home'
