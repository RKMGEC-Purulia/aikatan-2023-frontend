import React from 'react'

const Contact = () => {
  return <div>Contact Us</div>
}

export default Contact
