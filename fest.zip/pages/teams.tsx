import MemberCard from '@/components/MemberCard'

const Teams = () => {
  return (
    <section className=" w-full  pt-12">
      <h1 className=" text-3xl sm:text-4xl xl:text-5xl my-8 uppercase font-extrabold text-center">
        <span className=' text-transparent bg-gradient-to-r from-[#4776E6] to-[#8E54E9] bg-clip-text'>Teams</span>
      </h1>
      <div className=' flex flex-wrap gap-4 justify-center'>
                <MemberCard/>
            </div>
    </section>
  )
}

export default Teams
