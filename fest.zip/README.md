# aikatan-2023-frontend

## How to Run

```bash
pnpm i
```

```bash
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.
