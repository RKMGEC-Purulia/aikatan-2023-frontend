import { motion } from 'framer-motion'
import Image from 'next/image'
import { BsInstagram, BsLinkedin } from 'react-icons/bs'
import { membersDetails } from '@/data/member'

function MemberCard() {
    return (
        <>
            {membersDetails.map((member) => (
                <div
                    className=" w-48 sm:w-56  bg-gray-800 rounded-lg shadow-lg py-4 flex flex-col items-center space-y-3"
                    key={member.Timestamp}
                >
                    <div>
                        <div className=" w-24 h-24 sm:w-32 sm:h-32 rounded-full overflow-hidden ">
                            
                            <Image src={`https://drive.google.com/uc?export=view&id=${member.imgId}`} alt="" width={200} height={300} />
                        </div>
                    </div>
                    <div className=" text-center">
                        <h1 className=" text-lg sm:text-2xl font-semibold text-rose-500">
                            {member.name}
                        </h1>
                        <p className=" text-sm sm:text-base text-slate-300 font-medium">
                            {member.role}
                        </p>
                    </div>
                    <div className=" flex gap-4">
                        <motion.a
                            whileHover={{ scale: 1.1, color: '#4d81fa' }}
                            transition={{ duration: 0.3 }}
                            href={(member.Instagram) ?  member.Instagram : ""}
                            target="_blank">
                            <BsInstagram size={16} />
                        </motion.a>
                        <motion.a
                            whileHover={{ scale: 1.1, color: '#4d81fa' }}
                            transition={{ duration: 0.3 }}
                            href={(member.linkedIn) ? member.linkedIn : ""}
                            target="_blank">
                            <BsLinkedin size={16} />
                        </motion.a>
                    </div>
                </div>
            ))
            }
        </>
    )
}

export default MemberCard
